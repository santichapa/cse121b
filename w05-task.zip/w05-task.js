/* W05: Programming Tasks */

/* Declare and initialize global variables */


/* async displayTemples Function */




/* async getTemples Function using fetch()*/


/* reset Function */


/* sortBy Function */



getTemples();

/* Event Listener */
